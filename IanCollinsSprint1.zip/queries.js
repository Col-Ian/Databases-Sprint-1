const Pool = require("pg").Pool;
const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "IanCollinsSprint1",
  password: "admin",
  port: 5432,
});

const getPassengers = (request, response) => {
  pool.query(
    "SELECT * FROM sprint1_schema.passengers ORDER by id ASC",
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(200).json(results.rows);
    }
  );
};

const getPassengerById = (request, response) => {
  const id = parseInt(request.params.id);
  pool.query(
    `SELECT * FROM sprint1_schema.passengers WHERE id = $1`,
    [id],
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(200).json(results.rows);
    }
  );
};

const createPassenger = (request, response) => {
  const { id, first_name, last_name, phone_number, home_city } = request.body;

  pool.query(
    `INSERT INTO sprint1_schema.passengers (id, first_name, last_name, phone_number, home_city) VALUES ($1, $2, $3, $4, $5) RETURNING *`,
    [id, first_name, last_name, phone_number, home_city],
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(201).send(`User added with ID: ${results.rows[0].id}`);
    }
  );
};

const updatePassenger = (request, response) => {
  const id = parseInt(request.params.id);
  const { first_name, last_name, phone_number, home_city } = request.body;

  pool.query(
    `UPDATE sprint1_schema.passengers SET first_name = $1, last_name = $2, phone_number = $3, home_city = $4 WHERE id = $5`,
    [first_name, last_name, phone_number, home_city, id],
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(200).send(`User modified with ID: ${id}`);
    }
  );
};

const deletePassenger = (request, response) => {
  const id = parseInt(request.params.id);

  pool.query(
    "DELETE FROM sprint1_schema.passengers WHERE id = $1",
    [id],
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(200).send(`User deleted with ID: ${id}`);
    }
  );
};

module.exports = {
  getPassengers,
  getPassengerById,
  createPassenger,
  updatePassenger,
  deletePassenger,
};
